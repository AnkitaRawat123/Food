import React from 'react';
import './Orders.css';

function Orders() {
  return (
    <div>
      <h1>orders</h1>
    </div>
  )
}

export default Orders
